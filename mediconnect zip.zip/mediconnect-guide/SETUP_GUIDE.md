# MediConnect – Complete VS Code Setup Guide
## Step-by-step from zero to running app

---

## PREREQUISITES — Install these first

| Tool | Download | Check installed |
|------|----------|-----------------|
| Node.js 18+ | https://nodejs.org | `node -v` |
| VS Code | https://code.visualstudio.com | open app |
| Git (optional) | https://git-scm.com | `git --version` |

---

## STEP 1 — Create the React project

Open **Terminal** (in VS Code: `Ctrl+`` ` or `View > Terminal`)

```bash
# Go to your projects folder
cd C:\Users\YourName\Desktop        # Windows
# OR
cd ~/Desktop                         # Mac / Linux

# Create the app
npx create-react-app mediconnect

# Enter the folder
cd mediconnect
```

Wait 2–3 minutes for installation to complete.

---

## STEP 2 — Open in VS Code

```bash
code .
```

This opens the `mediconnect` folder in VS Code.

---

## STEP 3 — Understand the folder structure

After `create-react-app`, you get this structure:

```
mediconnect/
├── node_modules/        ← installed packages (DO NOT TOUCH)
├── public/
│   └── index.html       ← HTML shell (we edit this)
├── src/
│   ├── App.js           ← main component (we replace this)
│   ├── index.js         ← entry point (we edit this)
│   └── index.css        ← global styles (we edit this)
├── package.json         ← project config (we edit this)
└── README.md
```

---

## STEP 4 — Edit `public/index.html`

Open `public/index.html` and **replace ALL content** with:

```html
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta name="theme-color" content="#1A6B8A" />
    <meta name="description" content="MediConnect – India's Online Healthcare Platform" />
    <title>MediConnect India – Online Doctor Consultation</title>
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
      href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap"
      rel="stylesheet"
    />
  </head>
  <body>
    <noscript>You need to enable JavaScript to run this app.</noscript>
    <div id="root"></div>
  </body>
</html>
```

---

## STEP 5 — Edit `src/index.js`

Open `src/index.js` and **replace ALL content** with:

```javascript
import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
```

---

## STEP 6 — Edit `src/index.css`

Open `src/index.css` and **replace ALL content** with:

```css
/* Global Reset */
*, *::before, *::after {
  box-sizing: border-box;
  margin: 0;
  padding: 0;
}

html {
  font-size: 16px;
  scroll-behavior: smooth;
}

body {
  font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  background: #ffffff;
  color: #0D2B3E;
  min-height: 100vh;
}

/* Scrollbar styling */
::-webkit-scrollbar {
  width: 5px;
  height: 5px;
}
::-webkit-scrollbar-track {
  background: transparent;
}
::-webkit-scrollbar-thumb {
  background: rgba(26, 107, 138, 0.35);
  border-radius: 3px;
}
::-webkit-scrollbar-thumb:hover {
  background: rgba(26, 107, 138, 0.6);
}

/* Animations */
@keyframes slideIn {
  from { opacity: 0; transform: translateX(20px); }
  to   { opacity: 1; transform: none; }
}

@keyframes fadeIn {
  from { opacity: 0; transform: translateY(8px); }
  to   { opacity: 1; transform: none; }
}

@keyframes pulse {
  0%, 100% { opacity: 1; }
  50%       { opacity: 0.4; }
}

/* Utilities */
input, select, textarea, button {
  font-family: inherit;
}

a {
  text-decoration: none;
  color: inherit;
}

img {
  max-width: 100%;
  display: block;
}

/* Responsive helpers */
@media (max-width: 640px) {
  .hide-mobile {
    display: none !important;
  }
}
```

---

## STEP 7 — Create `src/App.js`

**DELETE** the existing content of `src/App.js`.
Then paste the entire MediConnect component code (from the App.jsx file provided separately).

The file starts with:
```javascript
import { useState, useEffect, useRef } from "react";
// ... (rest of the code)
export default function App() { ... }
```

> ⚠️ The full code is in `src/App.js` — see the separate file provided.

---

## STEP 8 — Edit `package.json`

Open `package.json`. Your file looks like this — just **verify** these dependencies exist (they come with create-react-app):

```json
{
  "name": "mediconnect",
  "version": "0.1.0",
  "private": true,
  "dependencies": {
    "react": "^18.2.0",
    "react-dom": "^18.2.0",
    "react-scripts": "5.0.1",
    "web-vitals": "^2.1.4"
  },
  "scripts": {
    "start": "react-scripts start",
    "build": "react-scripts build",
    "test": "react-scripts test",
    "eject": "react-scripts eject"
  },
  "eslintConfig": {
    "extends": ["react-app"]
  },
  "browserslist": {
    "production": [">0.2%", "not dead", "not op_mini all"],
    "development": ["last 1 chrome version", "last 1 firefox version", "last 1 safari version"]
  }
}
```

> No extra packages needed — MediConnect uses only built-in React and browser APIs.

---

## STEP 9 — Final folder structure

After all edits your `src/` folder looks like:

```
mediconnect/
├── public/
│   └── index.html          ← ✅ edited in Step 4
├── src/
│   ├── App.js              ← ✅ full MediConnect code (Step 7)
│   ├── index.js            ← ✅ edited in Step 5
│   └── index.css           ← ✅ edited in Step 6
├── package.json            ← ✅ verified in Step 8
└── node_modules/
```

That's it — only 3 source files to edit!

---

## STEP 10 — Run the app

In VS Code terminal:

```bash
npm start
```

Browser opens automatically at: **http://localhost:3000**

---

## DEMO LOGIN CREDENTIALS

| Role    | Email                    | Password   | What you see |
|---------|--------------------------|------------|--------------|
| Patient | rohit@patient.in         | patient123 | Patient Dashboard |
| Doctor  | priya@doctor.in          | doctor123  | Doctor Dashboard |
| Admin   | admin@mediconnect.in     | admin123   | Admin Panel |

Or click the **one-click demo buttons** on the login screen.

---

## FEATURES THAT WORK

### Patient Portal
- ✅ Browse & search Indian doctors (12 doctors, 21 cities)
- ✅ Filter by specialty, city, availability
- ✅ Book appointment with slot selection
- ✅ View/cancel appointments
- ✅ Download prescriptions as PDF (opens print dialog)
- ✅ Upload medical records (drag & drop or click)
- ✅ View & download uploaded records
- ✅ Payment history
- ✅ Profile with ABHA ID

### Doctor Portal
- ✅ Accept/reject appointment requests
- ✅ View patient history (full modal with vitals, visits, allergies)
- ✅ Video consultation room (uses your real webcam/mic via WebRTC)
- ✅ In-call chat, mute/unmute, camera on/off, call timer
- ✅ Write prescription with medicine builder
- ✅ Download prescription PDF directly
- ✅ Earnings dashboard with bar chart
- ✅ Sign out with confirmation

### Admin Portal
- ✅ Analytics with charts (appointments, top cities)
- ✅ Verify/remove doctors
- ✅ View appointment details (full modal)
- ✅ Download 4 real reports (opens print-ready HTML → Save as PDF)
- ✅ System settings with toggles
- ✅ Sign out with confirmation

### Global
- ✅ Dark mode toggle
- ✅ MediBot AI chatbot (powered by Claude API)
- ✅ Responsive design

---

## COMMON ERRORS & FIXES

### Error: `npm start` fails
```bash
# Delete node_modules and reinstall
rm -rf node_modules
npm install
npm start
```

### Error: `Cannot find module 'react-scripts'`
```bash
npm install react-scripts --save
npm start
```

### Error: `'React' must be in scope`
Make sure `src/index.js` has `import React from 'react';` at the top.

### White screen / nothing loads
- Check browser console (F12 → Console)
- Look for red error messages
- Make sure `src/App.js` has `export default function App()` at the bottom

### Camera not working in consultation
- Allow camera/microphone permissions in browser
- Works on Chrome, Firefox, Edge
- Safari may need `https://` — use Chrome for development

### MediBot AI not responding
- The chatbot calls the Anthropic API
- It will work when deployed with a valid API key proxy
- In local dev, responses may fail — this is expected

---

## BUILD FOR PRODUCTION

```bash
npm run build
```

Creates a `build/` folder — upload this to any web host:
- Netlify (drag & drop `build/` folder)
- Vercel (`vercel deploy`)
- GitHub Pages

---

## VS CODE EXTENSIONS (Recommended)

Install these from VS Code Extensions panel (`Ctrl+Shift+X`):

| Extension | ID | Why |
|-----------|-----|-----|
| ES7+ React Snippets | dsznajder.es7-react-js-snippets | React shortcuts |
| Prettier | esbenp.prettier-vscode | Auto-format code |
| Auto Rename Tag | formulahendry.auto-rename-tag | HTML tag editing |
| GitLens | eamodio.gitlens | Git integration |

---

## QUICK REFERENCE — Key Files

| File | Purpose |
|------|---------|
| `src/App.js` | Entire MediConnect application |
| `src/index.js` | React entry point |
| `src/index.css` | Global styles & animations |
| `public/index.html` | HTML shell with font imports |
| `package.json` | Project dependencies & scripts |

